package exception;

public class PasswordIncorrectException extends Exception {
	public PasswordIncorrectException(String errPassword) {
		super("Password error!");
	}
}
