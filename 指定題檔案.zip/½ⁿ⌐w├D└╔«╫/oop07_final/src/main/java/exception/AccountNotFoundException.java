package exception;

public class AccountNotFoundException extends Exception {
	
	public AccountNotFoundException(String errAccount) {
		super("Account error! Can not find " + errAccount);
	}
}
