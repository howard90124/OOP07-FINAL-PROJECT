package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DeliverManDao;
import exception.AccountNotFoundException;
import exception.PasswordIncorrectException;

@WebServlet("/DeliverManLogin")
public class DeliverManLoginServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private DeliverManDao dao=new DeliverManDao();
	public DeliverManLoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("DeliverManLogin.jsp");
		
		dispatcher.forward(request, response);
		return;
	};
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String account = request.getParameter("account");
		String password = request.getParameter("password");
		int id = 0;
		try {
			id = dao.login(account, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (AccountNotFoundException e) {
			request.setAttribute("message", e.getMessage());
			request.getRequestDispatcher("DeliverManLogin.jsp").forward(request, response);
		} catch (PasswordIncorrectException e) {
			request.setAttribute("message", e.getMessage());
			request.getRequestDispatcher("DeliverManLogin.jsp").forward(request, response);
		}
		
		request.setAttribute("id", id);
		request.setAttribute("ordernum", "0");
		request.getRequestDispatcher("DeliverManHomePage.jsp").forward(request, response);
	}
}
