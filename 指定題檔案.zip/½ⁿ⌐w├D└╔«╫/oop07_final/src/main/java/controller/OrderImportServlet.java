package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import role.Order;
import dao.OrderImportDao;
import dao.StoreDao;

/**
 * get parameter of order from mysql
 */
@WebServlet("/OrderImport")
public class OrderImportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private OrderImportDao dao=new OrderImportDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderImportServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("OrderConfirm.jsp");
		
		dispatcher.forward(request, response);
		return;
	};

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String amount = request.getParameter("amount");
		String store_name  = request.getParameter("store_name");
		String customer_name = request.getParameter("customer_name");
		String destination = request.getParameter("destination");
		String content = request.getParameter("content");
		String customerid = request.getParameter("id");
		String id = null;
		try {
			id = ""+findNewId();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//---------------------------------------------------------------------
		
		StoreDao sdao = new StoreDao();
		ArrayList<String> storeInfoArrayList = new ArrayList<>();
		try {
			storeInfoArrayList = sdao.findByName(store_name);
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		
		Order ord=new Order();
		
		Date date = Calendar.getInstance().getTime();  
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");  
		String strDate = dateFormat.format(date);  
		
		//--------------------------------------------------------------
		String orderable="false";
	    //�N�{�b���ɶ��ন�P��
	    Date datenow = new Date(System.currentTimeMillis());
		SimpleDateFormat date2DayFormat = new SimpleDateFormat( "u" );
		String week= date2DayFormat.format(datenow);
		System.out.println(week);
		
		DateTimeFormatter change = DateTimeFormatter.ofPattern("HH:mm");
		SimpleDateFormat  change2 = new SimpleDateFormat( "HH:mm" );		
		Date date_now = null;
		try {
			date_now = change2.parse(change.format(LocalDateTime.now()));
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	   //week ����P���X�A�O1~7���Ʀr
	  if(week.equals("1")){
		  	//���ӼƦr�P�����}���ɶ��������ɶ�
		  	String open ="";
		  	String end ="";
			open = storeInfoArrayList.get(8);
			end = storeInfoArrayList.get(9);
			//System.out.println(open);
			//System.out.println(end);
		 
		  	Date open_time = new Date();
			try {
				open_time = new SimpleDateFormat("HH:mm").parse(open);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	Date close_time = new Date();
			try {
				close_time = new SimpleDateFormat("HH:mm").parse(end);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	//�p�G�{�b�ɶ��b�}���ɶ��������ɶ������N�g�i�H�U�q
		  	if((date_now.after(open_time)&&date_now.before(close_time))){
			    orderable="true";
		  	}
	  }
	  if(week.equals("2")){
		  	//���ӼƦr�P�����}���ɶ��������ɶ�
		  	String open ="";
		  	String end ="";
			open = storeInfoArrayList.get(10);
			end = storeInfoArrayList.get(11);
		 
		  	Date open_time = new Date();
			try {
				open_time = new SimpleDateFormat("HH:mm").parse(open);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	Date close_time = new Date();
			try {
				close_time = new SimpleDateFormat("HH:mm").parse(end);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	//�p�G�{�b�ɶ��b�}���ɶ��������ɶ������N�g�i�H�U�q
		  	if(date_now.after(open_time)&&date_now.before(close_time)){
			    orderable="true";
		  	}
	  }
	  if(week.equals("3")){
		  	//���ӼƦr�P�����}���ɶ��������ɶ�
		  	String open ="";
		  	String end ="";
			open = storeInfoArrayList.get(12);
			end = storeInfoArrayList.get(13);
		 
		  	Date open_time = new Date();
			try {
				open_time = new SimpleDateFormat("HH:mm").parse(open);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	Date close_time = new Date();
			try {
				close_time = new SimpleDateFormat("HH:mm").parse(end);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	//�p�G�{�b�ɶ��b�}���ɶ��������ɶ������N�g�i�H�U�q
		  	if(date_now.after(open_time)&&date_now.before(close_time)){
			    orderable="true";
		  	}
	  }
	  if(week.equals("4")){
		  	//���ӼƦr�P�����}���ɶ��������ɶ�
		  	String open ="";
		  	String end ="";
			open = storeInfoArrayList.get(14);
			end = storeInfoArrayList.get(15);
		 
		  	Date open_time = new Date();
			try {
				open_time = new SimpleDateFormat("HH:mm").parse(open);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	Date close_time = new Date();
			try {
				close_time = new SimpleDateFormat("HH:mm").parse(end);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	//�p�G�{�b�ɶ��b�}���ɶ��������ɶ������N�g�i�H�U�q
		  	if(date_now.after(open_time)&&date_now.before(close_time)){
			    orderable="true";
		  	}
	  }
	  if(week.equals("5")){
		  	//���ӼƦr�P�����}���ɶ��������ɶ�
		  	String open ="";
		  	String end ="";
			open = storeInfoArrayList.get(16);
			end = storeInfoArrayList.get(17);
		 
		  	Date open_time = new Date();
			try {
				open_time = new SimpleDateFormat("HH:mm").parse(open);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	Date close_time = new Date();
			try {
				close_time = new SimpleDateFormat("HH:mm").parse(end);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	//�p�G�{�b�ɶ��b�}���ɶ��������ɶ������N�g�i�H�U�q
		  	if(date_now.after(open_time)&&date_now.before(close_time)){
			    orderable="true";
		  	}
	  }
	  if(week.equals("6")){
		  	//���ӼƦr�P�����}���ɶ��������ɶ�
		  	String open ="";
		  	String end ="";
			open = storeInfoArrayList.get(18);
			end = storeInfoArrayList.get(19);
		 
		  	Date open_time = new Date();
			try {
				open_time = new SimpleDateFormat("HH:mm").parse(open);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	Date close_time = new Date();
			try {
				close_time = new SimpleDateFormat("HH:mm").parse(end);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	//�p�G�{�b�ɶ��b�}���ɶ��������ɶ������N�g�i�H�U�q
		  	if(date_now.after(open_time)&&date_now.before(close_time)){
			    orderable="true";
		  	}
	  }
	  if(week.equals("7")){
		  	//���ӼƦr�P�����}���ɶ��������ɶ�
		  	String open ="";
		  	String end ="";
			open = storeInfoArrayList.get(20);
			end = storeInfoArrayList.get(21);
		 
		  	Date open_time = new Date();
			try {
				open_time = new SimpleDateFormat("HH:mm").parse(open);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	Date close_time = new Date();
			try {
				close_time = new SimpleDateFormat("HH:mm").parse(end);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	//�p�G�{�b�ɶ��b�}���ɶ��������ɶ������N�g�i�H�U�q
		  	if(date_now.after(open_time)&&date_now.before(close_time)){
			    orderable="true";
		  	}
	  }
		if(orderable.equals("false")){
			request.setAttribute("id", customerid);
			request.getRequestDispatcher("NotOnTheTime.jsp").forward(request, response);
		}else {
		//--------------------------------------------------------------
		
		ord.setAmount(amount);
		ord.setContent(content);
		ord.setCustomer_name(customer_name);
		ord.setStore_name(store_name);
		ord.setDestination(destination);
		ord.setOrdertime(strDate);
		ord.setCustomerid(customerid);
		ord.setId(id);
		
		
		try {
			dao.OrderImport(ord);
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		
		request.setAttribute("id", customerid);
		request.getRequestDispatcher("OrderDetail.jsp").forward(request, response);
		//response.sendRedirect("OrderDetail.jsp");
	}
}

private int findNewId() throws ClassNotFoundException {
    Class.forName("com.mysql.jdbc.Driver");
    String INSERT_USERS_SQL = "SELECT MAX(id) FROM `order`;";
    try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
        java.sql.Statement state = connection.createStatement();
        ResultSet rst = state.executeQuery(INSERT_USERS_SQL);
        if (rst.next()) {
            return rst.getInt(1) + 1;
        }
    } catch (SQLException e) {
        printSQLException(e);
    }
    return 0;
}
private void printSQLException(SQLException ex) {
    for (Throwable e: ex) {
        if (e instanceof SQLException) {
            e.printStackTrace(System.err);
            System.err.println("SQLState: " + ((SQLException) e).getSQLState());
            System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
            System.err.println("Message: " + e.getMessage());
            Throwable t = ex.getCause();
            while (t != null) {
                System.out.println("Cause: " + t);
                t = t.getCause();
            }
        }
    }
}
}


