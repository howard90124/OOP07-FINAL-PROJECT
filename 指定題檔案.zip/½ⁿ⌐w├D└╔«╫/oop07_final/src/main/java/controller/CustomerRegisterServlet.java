package controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CustomerDao;
import role.Customer;

/**
 * Servlet implementation class customer_servlet
 */
@WebServlet("/CustomerRegister")
public class CustomerRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private CustomerDao dao=new CustomerDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerRegister.jsp");
		
		dispatcher.forward(request, response);
		return;
	};

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String phone = request.getParameter("phone");
		String name  = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		Customer cust=new Customer();
		cust.setPhone(phone);
		cust.setName(name);
		cust.setEmail(email);
		cust.setPassword(password);
		cust.setVip(Date.valueOf("2020-01-01"));
		
		if(phone!="")
			if(name!="")
				if(email!="")
					if(password!="") {
						try {
							dao.registercustomer(cust);
						}catch(ClassNotFoundException e) {
							e.printStackTrace();
						}
						request.setAttribute("name",name);
						request.getRequestDispatcher("AccountSuccess.jsp").forward(request, response);
					}
			request.setAttribute("message", "�W�z��줣��ť�");
			request.getRequestDispatcher("AccountApplyCustomer.jsp").forward(request, response);
	}

}
