package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CustomerDao;
import dao.DeliverManDao;
import dao.StoreDao;

@WebServlet("/ResetPassword")
public class ResetPasswordServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	public ResetPasswordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("ResetPassword.jsp");
		
		dispatcher.forward(request, response);
		return;
	};
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		request.setCharacterEncoding("UTF-8");
		String[] strs = request.getSession().getAttribute("ChooseForgetAccount").toString().split(" ",2);
		String identity = strs[0];
		String key = strs[1];
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");
		if(!password.equals(password2)) {
			request.setAttribute("message", "�K�X��J���@�P");
			request.getRequestDispatcher("ResetPasswordCenter.jsp").forward(request, response);
		}
			switch(identity){
			case "Customer":
				CustomerDao dao = new CustomerDao();
				dao.resetPassword(Integer.parseInt(key), password);
				break;
			case "DeliverMan":
				DeliverManDao dao2 = new DeliverManDao();
				dao2.resetPassword(Integer.parseInt(key), password);
				break;
			case "Store":
				StoreDao dao3 = new StoreDao();
				dao3.resetPassword(key, password);
				break;
		};
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			request.setAttribute("message", "�ФŪťաI");
			request.getRequestDispatcher("ResetPasswordCenter.jsp").forward(request, response);
		}
		response.sendRedirect("ResetPasswordSuccess.jsp");
		
		
	}
}
