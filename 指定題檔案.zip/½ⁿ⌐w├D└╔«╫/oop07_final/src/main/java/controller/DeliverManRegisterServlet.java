package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DeliverManDao;
import role.DeliverMan;

/**
 * Servlet implementation class customer_servlet
 */
@WebServlet("/DeliverManRegister")
public class DeliverManRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private DeliverManDao dao=new DeliverManDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeliverManRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("DeliverManRegister.jsp");
		
		dispatcher.forward(request, response);
		return;
	};

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String phone = request.getParameter("phone");
		String name  = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		DeliverMan del=new DeliverMan();
		del.setPhone(phone);
		del.setName(name);
		del.setEmail(email);
		del.setPassword(password);
		
		if(phone!="")
			if(name!="")
				if(email!="")
					if(password!="") {
						try {
							dao.registerdeliver_man(del);
						}catch(ClassNotFoundException e) {
							e.printStackTrace();
						}
						request.setAttribute("name",name);
						request.getRequestDispatcher("AccountSuccess.jsp").forward(request, response);
					}
		
		request.setAttribute("message", "�W�z��줣��ť�");
		request.getRequestDispatcher("AccountApplyDeliver.jsp").forward(request, response);
	}

}
