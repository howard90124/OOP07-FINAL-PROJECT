package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.StoreDao;

@WebServlet("/StoreNewOrderDescription")
public class StoreResetOrderDescriptionServlet extends HttpServlet{
	StoreDao dao = new StoreDao();

	public StoreResetOrderDescriptionServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("StoreModifyOrderDescription.jsp");
		
		dispatcher.forward(request, response);
		return;
	};
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String name = request.getSession().getAttribute("ModifyOrderDescription").toString();
			String orderdescription = request.getParameter("NewOrderDescription");
			dao.resetOrderDescription(name, orderdescription);
			request.setAttribute("store_id", name);
			request.getRequestDispatcher("ResetOrderDescriptionSuccess.jsp").forward(request, response);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		
		
	}
}
