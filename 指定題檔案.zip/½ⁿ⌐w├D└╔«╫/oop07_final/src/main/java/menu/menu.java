
package menu;

public class menu {
String dishes;
String price;
 



public menu() {
	 
 }




public String getDishes() {
	return dishes;
}




public void setDishes(String dishes) {
	this.dishes = dishes;
}




public String getPrice() {
	return price;
}




public void setPrice(String price) {
	this.price = price;
}





 
}