package loader;
import java.sql.*;
public class DB_loader {
//database
	private static final String JDBC_DRIVER="com.mysql.cj.jdbc.Driver";
	private static final String url="jdbc:mysql://127.0.0.1:3306/deliver?useSSL=false&serverTimezone=UTC";
	
//user and password
	private static final String user="root";
	private static final String password="3245";
	
	private static Connection conn=null;

	static
	{
		try {
			Class.forName(JDBC_DRIVER);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() throws Exception
	{
		if(conn==null) {
			conn=DriverManager.getConnection(url,user,password);
			return conn;
		}
		return conn;
	}
	
	
	public static void main(String[] args) {
		try {
			Connection conn = DB_loader.getConnection();
			if(conn !=null) {
				System.out.println("Success !");
			}
			else {
				System.out.println("Fail QQ !");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}