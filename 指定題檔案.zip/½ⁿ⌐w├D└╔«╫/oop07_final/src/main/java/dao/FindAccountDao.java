package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.catalina.filters.SetCharacterEncodingFilter;

import exception.AccountNotFoundException;
import role.Customer;
import role.DeliverMan;
import role.Role;
import role.Store;

/**
 * find 3 type roles 's of account 
 *
 */
public class FindAccountDao {
	public ArrayList<Role> findByEmailAndName(String email, String name)
			throws AccountNotFoundException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		String INSERT_USERS_SQL_FOR_CUSTOMER = "SELECT * FROM customer WHERE email LIKE \"" + email
				+ "\" AND name LIKE\"" + name + "\";";
		String INSERT_USERS_SQL_FOR_DELIVERMAN = "SELECT * FROM deliver_man WHERE email LIKE \"" + email
				+ "\" AND name LIKE\"" + name + "\";";
		String INSERT_USERS_SQL_FOR_STORE = "SELECT * FROM stores_detail WHERE email LIKE \"" + email
				+ "\" AND name LIKE\"" + name + "\";";
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root",
				"3245")) {
			java.sql.Statement state = connection.createStatement();
			ArrayList<Role> accountList = new ArrayList<>();
			Boolean hasInfo = false;

			ResultSet rst = state.executeQuery(INSERT_USERS_SQL_FOR_CUSTOMER);
			while (rst.next()) {
				Customer c = new Customer();
				c.setEmail(rst.getString(4));
				c.setId(rst.getInt(1));
				c.setName(rst.getString(3));
				c.setPassword(rst.getString(5));
				c.setPhone(rst.getString(2));
				//c.setVip(rst.getDate(6));
				accountList.add(c);
				hasInfo = true;
			}

			rst = state.executeQuery(INSERT_USERS_SQL_FOR_DELIVERMAN);
			while (rst.next()) {
				DeliverMan d = new DeliverMan();
				d.setEmail(rst.getString(1));
				d.setId(rst.getInt(5));
				d.setName(rst.getString(3));
				d.setPassword(rst.getString(2));
				d.setPhone(rst.getString(4));
				accountList.add(d);
				hasInfo = true;
			}
			rst = state.executeQuery(INSERT_USERS_SQL_FOR_STORE);
			while (rst.next()) {
				Store s = new Store();
				s.setEmail(rst.getString(9));
				// s.setId(rst.getInt(11));
				s.setName(rst.getString(1));
				s.setPassword(rst.getString(10));
				s.setPhone(rst.getString(3));
				s.setPosition(rst.getString(2));
				accountList.add(s);
				hasInfo = true;
			}

			if (!hasInfo) {
				throw new AccountNotFoundException("email: " + email + " with name: " + name);
			}
			return accountList;
		} catch (SQLException e) {
			printSQLException(e);
		}
		return null;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}
