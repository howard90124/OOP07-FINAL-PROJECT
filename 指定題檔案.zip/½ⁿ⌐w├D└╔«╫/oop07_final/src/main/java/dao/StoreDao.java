package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exception.AccountNotFoundException;
import exception.PasswordIncorrectException;
import role.Store;


/**
 *  write email and password into table stores_detail ,sign up account
 *
 */
public class StoreDao extends RoleDao{

    public int registerstore(Store store) throws ClassNotFoundException {
    	
        String INSERT_USERS_SQL = "UPDATE stores_detail SET email=?, password=? WHERE name=?";

        
        int result = 0;

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245");	
        	
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
        	

            
            preparedStatement.setString(1, store.getEmail());
            preparedStatement.setString(2, store.getPassword());
            preparedStatement.setString(3, store.getName());

            System.out.println(preparedStatement);

            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {

            printSQLException(e);
        }
        return result;
    }

    public String login(String account, String password) throws ClassNotFoundException, PasswordIncorrectException, AccountNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "SELECT * FROM stores_detail WHERE email LIKE \"" + account + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		ResultSet rst = state.executeQuery(INSERT_USERS_SQL);
    		
    		if(rst.next()) {
    			if(!password.equals(rst.getString(10))) {
    				throw new PasswordIncorrectException(password);
    			} else {
					return rst.getString(1);
				}
    		} else {
				throw new AccountNotFoundException(account);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return "";
	}
    
    public void resetPassword(String name, String password) throws ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "UPDATE stores_detail SET password=\"" + password + "\" WHERE name=\"" + name + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		state.executeUpdate(INSERT_USERS_SQL);
			
    	} catch (SQLException e) {
			printSQLException(e);
		}
    }
    
    public void resetPhoneNumber(String name, String phonenumber) throws ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "UPDATE stores_detail SET phone=\"" + phonenumber + "\" WHERE name=\"" + name + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		state.executeUpdate(INSERT_USERS_SQL);
			
    	} catch (SQLException e) {
			printSQLException(e);
		}
    }
    
    public void resetStoreDescription(String name, String storeDescription) throws ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "UPDATE stores_detail SET store_description=\"" + storeDescription + "\" WHERE name=\"" + name + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		state.executeUpdate(INSERT_USERS_SQL);
			
    	} catch (SQLException e) {
			printSQLException(e);
		}
    }
    
    public void resetOrderDescription(String name, String orderDescription) throws ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "UPDATE stores_detail SET order_description=\"" + orderDescription + "\" WHERE name=\"" + name + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		state.executeUpdate(INSERT_USERS_SQL);
			
    	} catch (SQLException e) {
			printSQLException(e);
		}
    }
    
    public ArrayList<String> findByName(String name) throws ClassNotFoundException{
    	ArrayList<String> arrayList = new ArrayList<>();
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "SELECT * FROM stores_detail WHERE name LIKE \"" + name + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		ResultSet rst = state.executeQuery(INSERT_USERS_SQL);
    		if (rst.next()) {
    			
				arrayList.add(rst.getString(1));
				arrayList.add(rst.getString(3));
				arrayList.add(rst.getString(4));
				arrayList.add(rst.getString(5));
				arrayList.add(rst.getString(9));
			}
    		rst = state.executeQuery("SELECT * FROM position WHERE name LIKE \"" + name + "\";");
			if (rst.next()) {
				arrayList.add(rst.getString(1));
				arrayList.add(rst.getString(2));
				arrayList.add(rst.getString(3));
			}
			rst = state.executeQuery("SELECT * FROM business_time WHERE name LIKE \"" + name + "\";");
			if (rst.next()) {
				arrayList.add(rst.getString(2));
				arrayList.add(rst.getString(3));
				arrayList.add(rst.getString(4));
				arrayList.add(rst.getString(5));
				arrayList.add(rst.getString(6));
				arrayList.add(rst.getString(7));
				arrayList.add(rst.getString(8));
				arrayList.add(rst.getString(9));
				arrayList.add(rst.getString(10));
				arrayList.add(rst.getString(11));
				arrayList.add(rst.getString(12));
				arrayList.add(rst.getString(13));
				arrayList.add(rst.getString(14));
				arrayList.add(rst.getString(15));
			}
    	} catch (SQLException e) {
			printSQLException(e);
		}
    	return arrayList;
    }
    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}