
package dao;
import menu.menu;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


import loader.loader;


/**
 * load certain store's menu(dishes price) from mysql
 *
 */
public class menuDao {
	private String store = null;
	public menuDao(String s) {
		store = s;
	}
	public ArrayList<menu> getAllitems(){

		Connection conn=null;
		ResultSet result=null;
		PreparedStatement state=null;
		
		
		ArrayList<menu> list =new ArrayList<menu>();
		try {
			
			
			conn=loader.getConnection();
			String sql="select dishes,price from menu where name = \""+store+"\";";
			state = conn.prepareStatement(sql);
			result=state.executeQuery();
			while(result.next()) {
				menu m = new menu();
				m.setDishes(result.getString("dishes"));
				m.setPrice(result.getString("price"));
				list.add(m);
			}
			return list;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}finally {
			if(result!=null) {
				try {
					result.close();
					result=null;
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
			if(state!= null) {
				try {
					state.close();
					state=null;
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}