package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import role.Order;


/**
 *  write information into order table including status, amount, destination address, customer name, store name,content,order time,id,customer id
 *
 */
public class OrderImportDao{

    public int OrderImport(Order order) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO `order`" +
            "  (status, amount, destination_address, customer_name, store_name,`�\�I���e`,order_time,id,customer_id) VALUES " +
            " (\"�s�@��\", ?, ?, ?, ?,?,?,?,?);";
        
        int result = 0;

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245");	
        	
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
        	
        	preparedStatement.setString(1, order.getAmount());
        	preparedStatement.setString(2, order.getDestination());
            preparedStatement.setString(3, order.getCustomer_name());
            preparedStatement.setString(4, order.getStore_name());
            preparedStatement.setString(5, order.getContent());
            preparedStatement.setString(6, order.getOrdertime());
            preparedStatement.setString(7, order.getId());
            preparedStatement.setString(8, order.getCustomerid());


            System.out.println(preparedStatement);

            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {

            printSQLException(e);
        }
        return result;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}