package dao;

public abstract class RoleDao {
	
}
