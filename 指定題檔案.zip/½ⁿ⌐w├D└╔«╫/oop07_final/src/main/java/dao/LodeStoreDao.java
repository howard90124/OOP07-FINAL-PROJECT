package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import loader.DB_loader;
import store.StoreInfo;


public class LodeStoreDao {
	public ArrayList<StoreInfo> getAllitems(){
		Connection conn=null;
		ResultSet result=null;
		ResultSet result2=null;
		PreparedStatement state=null;
		PreparedStatement state2=null;
		
		ArrayList<StoreInfo> list =new ArrayList<StoreInfo>();
		try {
			
			conn=DB_loader.getConnection();
			String sql="select address from  position;";
			String sql2="select name,phone from  stores_detail;";
			state  = conn.prepareStatement(sql);
			state2 = conn.prepareStatement(sql2);
			result=state.executeQuery();
			result2=state2.executeQuery();
			while(result.next()&&result2.next()) {
				StoreInfo p = new StoreInfo();
				p.setAddress(result.getString("address"));
				p.setName(result2.getString("name"));
				p.setPhone(result2.getString("phone"));
				list.add(p);
			}
			return list;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}finally {
			if(result!=null) {
				try {
					result.close();
					result=null;
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
			if(state!= null) {
				try {
					state.close();
					state=null;
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}
