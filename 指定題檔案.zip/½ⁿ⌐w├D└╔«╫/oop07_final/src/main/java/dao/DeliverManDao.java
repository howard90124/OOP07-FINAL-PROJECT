package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exception.AccountNotFoundException;
import exception.PasswordIncorrectException;
import role.DeliverMan;


public class DeliverManDao extends RoleDao{

    public int registerdeliver_man(DeliverMan del) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO deliver_man" +
            "  ( phone, name, email, password, id) VALUES " +
            " (?, ?, ?, ?, ?)";
        
        int result = 0;
        int id = findNewId();
        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245");	
        	
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
        	
        	preparedStatement.setInt(5, id);
        	preparedStatement.setString(1, del.getPhone());
            preparedStatement.setString(2, del.getName());
            preparedStatement.setString(3, del.getEmail());
            preparedStatement.setString(4, del.getPassword());


            System.out.println(preparedStatement);

            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {

            printSQLException(e);
        }
        return result;
    }

    
    public int login(String account, String password) throws ClassNotFoundException, AccountNotFoundException, PasswordIncorrectException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "SELECT * FROM deliver_man WHERE email LIKE \"" + account + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		ResultSet rst = state.executeQuery(INSERT_USERS_SQL);
    		
    		if(rst.next()) {
    			if(!password.equals(rst.getString(2))) {
    				throw new PasswordIncorrectException(password);
    			} else {
					return rst.getInt(5);
				}
    		} else {
				throw new AccountNotFoundException(account);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return 0;
	}
    
    private int findNewId() throws ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "SELECT MAX(id) FROM deliver_man;";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		ResultSet rst = state.executeQuery(INSERT_USERS_SQL);
    		if (rst.next()) {
					return rst.getInt(1) + 1;
				}
			
    	} catch (SQLException e) {
			printSQLException(e);
		}
    	return 0;
    }
    
    public void resetPassword(int id, String password) throws ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "UPDATE deliver_man SET password=\"" + password + "\" WHERE id=\"" + id + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		state.executeUpdate(INSERT_USERS_SQL);
			
    	} catch (SQLException e) {
			printSQLException(e);
		}
    }
    
    public void resetPhoneNumber(int id, String phonenumber) throws ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "UPDATE deliver_man SET phone=\"" + phonenumber + "\" WHERE id=\"" + id + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		state.executeUpdate(INSERT_USERS_SQL);
			
    	} catch (SQLException e) {
			printSQLException(e);
		}
    }
    
    public void resetName(int id, String name) throws ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "UPDATE deliver_man SET name=\"" + name + "\" WHERE id=\"" + id + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		state.executeUpdate(INSERT_USERS_SQL);
			
    	} catch (SQLException e) {
			printSQLException(e);
		}
    }
    
    public ArrayList<String> findById(int id) throws ClassNotFoundException{
    	ArrayList<String> arrayList = new ArrayList<>();
    	Class.forName("com.mysql.jdbc.Driver");
    	String INSERT_USERS_SQL = "SELECT * FROM deliver_man WHERE id LIKE \"" + id + "\";";
    	try(Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/deliver", "root", "3245")) {
    		java.sql.Statement state = connection.createStatement();
    		ResultSet rst = state.executeQuery(INSERT_USERS_SQL);
    		if (rst.next()) {
    			String idString = "" + rst.getInt(5);
    			
				arrayList.add(rst.getString(1));
				arrayList.add(rst.getString(2));
				arrayList.add(rst.getString(3));
				arrayList.add(rst.getString(4));
				arrayList.add(idString);
			}
			
    	} catch (SQLException e) {
			printSQLException(e);
		}
    	return arrayList;
    }
    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}