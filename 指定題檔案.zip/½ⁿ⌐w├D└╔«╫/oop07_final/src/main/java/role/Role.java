package role;

public abstract class Role {

}
